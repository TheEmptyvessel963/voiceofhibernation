---
title: "The Nature of Expertise"
date: 2026-09-16 06:30:00 +0000
categories: cognition
excerpt: "What separates genuine expertise from the illusion of it? Chess masters, overconfident beginners, and a few surprising studies."
toc: true
toc_label: "In this post"
---

## 🧠 The Central Question

How do we know when someone is truly an expert versus someone who merely sounds like one?

The illusion of knowledge is perhaps more dangerous than simple ignorance. When you don't know something, you can at least search for answers. When you *think* you know something, the search stops.

> **💡 Quick version:** Real expertise is a huge library of patterns, built through practice and feedback, plus the honesty to know where that library ends. Confidence alone proves nothing.

## 🎯 The Confidence Trap

In 1999, psychologists Justin Kruger and David Dunning ran four studies testing people on humor, grammar, and logic. Then they asked everyone to guess how well they had done. The people in the bottom quarter scored around the 12th percentile, yet they estimated themselves at about the 62nd [1].

Their explanation was a "dual burden": the skills needed to do something well are often the same skills needed to notice you are doing it badly. If you can't spot a good argument, you can't spot that yours is weak. In their experiments, training people in the skill also helped them see their own limits [1].

**⚠️ A fair warning.** This famous result is debated. Some researchers argue the pattern is partly a statistical artifact, caused by the "better than average" bias and regression to the mean [2]. Others have replied that those critiques have their own measurement problems [3]. Also, the popular "Mount Stupid" curve you see online is not from the original paper. So the safe takeaway is modest: people are often poor judges of their own skill, especially when they are new to something.

## 🔑 Key Distinctions

- **Knowing about** vs. **knowing how**
- **Performance in familiar conditions** vs. **performance under novelty**
- **Articulating knowledge** vs. **applying it**

Someone can explain swimming perfectly and still sink. Someone else can swim beautifully and be unable to explain how. Fluent talk is not proof of skill, and skill is not always fluent talk.

## ♟️ What Chess Taught Us

Chess is the classic laboratory for studying expertise, because skill can be measured exactly through ratings and results.

**Step 1: de Groot.** Dutch psychologist Adriaan de Groot asked chess players of different strengths to think aloud while choosing a move. The surprise was that masters did not search dramatically more moves than weaker players. They just *saw* the strong candidate moves almost at once [4].

**Step 2: Chase and Simon.** In 1973, William Chase and Herbert Simon followed up. Players looked at a board for about five seconds, then rebuilt it from memory. Better players did much better with real game positions, but that advantage mostly vanished with randomly placed pieces [5]. (Their study used just three players, a master, an advanced player, and a beginner, so later research was needed to confirm the idea.)

So masters don't have a magic memory. They have **chunks**: stored patterns that mean something, like a familiar castled king with its pawn shield. Simon and Gilmartin later estimated that a master holds tens of thousands of such patterns [6].

![Illustration: a beginner sees twelve separate pieces while a master sees the same pieces as three meaningful chunks](/assets/images/expertise/chunking.svg)
*A beginner sees pieces. A master sees patterns.*

![Schematic showing masters recall far more pieces from real positions, but the advantage mostly disappears for random positions](/assets/images/expertise/real-vs-random.svg)
*Schematic of the finding in [5]. Bar heights are illustrative, not the study's real numbers.*

This is what "pattern recognition" really means. It isn't mysterious intuition. It is a large library built from years of seeing the same kinds of situations and learning what happens next.

## ✅ What Real Expertise Looks Like

Experts tend to:

1. **Know the limits of their knowledge (metacognition).** They say "it depends" and "I'm not sure" more often, and can tell you *when* their method stops working.
2. **Reason differently in their domain.** Beginners analyze step by step. Experts recognize the situation first, then check it. Pattern recognition does the heavy lifting, and deliberate analysis double-checks.
3. **Perform well under time pressure.** Their knowledge is already organized, so they don't have to build the answer from scratch.

## 🚦 But Can You Always Trust an Expert's Gut?

No, and this is where it gets interesting. Psychologist Daniel Kahneman, who studied how intuition goes wrong, worked with Gary Klein, who studied how it goes right (for example, in firefighters). After years of debate they agreed on two conditions for trustworthy intuition: the environment must be regular enough to have learnable patterns, and the person must have had real chances to practice with clear feedback. They also stressed that how *sure* someone feels is not a reliable sign of how *right* they are [7].

![A two by two grid showing intuition is trustworthy only when the world is regular and feedback is fast and clear](/assets/images/expertise/trust-intuition.svg)
*Simplified from [7].*

Psychologist Philip Tetlock tested the other side. He collected about 28,000 predictions from 284 experts on world affairs over roughly two decades. Overall, the experts did little better than simple forecasting rules, and the most confident ones were not the most accurate [8]. The better forecasters were the "foxes," who know many small things and change their minds, rather than the "hedgehogs," who know one big idea and defend it [8]. 🦊🦔

So the honest question is not just "is this person smart?" but "did their field ever give them a fair chance to learn?"

## 📚 Practice Matters, But Not Just Hours

Anders Ericsson and colleagues proposed **deliberate practice**: focused effort on your weak spots, ideally with a teacher and quick feedback [9]. That is why someone can work in a field for 20 years and improve little after the first two.

The popular "10,000 hours" idea oversimplifies it, though. A large meta-analysis of 88 studies found that practice explained very different amounts of skill differences depending on the field [10]:

| Field | Share of performance differences explained by deliberate practice |
|---|---|
| Games (like chess) | 26% |
| Music | 21% |
| Sports | 18% |
| Education | 4% |
| Professions | less than 1% |

The authors concluded practice is important but not as important as some claimed. Ericsson replied that they counted many kinds of practice that don't fit his strict definition [11]. This debate is still alive, and the fair summary is: practice clearly helps, and how much depends on the field and on what counts as "deliberate."

## 🔍 How to Spot Real Expertise

Since we can't always test someone directly, a few questions help:

- ❓ **Can they tell you where their advice fails?** Real experts know the edge cases.
- 🔄 **What would change their mind?** If nothing could, be careful.
- 📈 **Do they have a track record with feedback?** Predictions that were checked matter more than opinions never tested.
- 🌱 **Do they stay useful when the problem is new?** Someone who only handles textbook cases may be trained but not expert.
- 🙋 **Do they stay humble outside their field?** Expertise in one area doesn't carry over to others.

## 🌊 Closing Thought

Expertise is not a feeling of confidence. It is a library of patterns, built through feedback, that lets you handle what's new and know where your map ends. The most reliable sign of it may be the willingness to say, "this is where my knowledge stops."

---

## 📖 References

1. Kruger, J., & Dunning, D. (1999). Unskilled and unaware of it: How difficulties in recognizing one's own incompetence lead to inflated self-assessments. *Journal of Personality and Social Psychology, 77*(6), 1121-1134. [doi:10.1037/0022-3514.77.6.1121](https://doi.org/10.1037/0022-3514.77.6.1121)
2. Gignac, G. E., & Zajenkowski, M. (2020). The Dunning-Kruger effect is (mostly) a statistical artefact. *Intelligence, 80*, 101449. [doi:10.1016/j.intell.2020.101449](https://doi.org/10.1016/j.intell.2020.101449)
3. Dunkel, C. S., Nedelec, J., & van der Linden, D. (2023). Reevaluating the Dunning-Kruger effect: A response to and replication of Gignac and Zajenkowski (2020). *Intelligence, 96*, 101717.
4. de Groot, A. D. (1965). *Thought and Choice in Chess.* Mouton. (Original Dutch thesis, 1946.)
5. Chase, W. G., & Simon, H. A. (1973). Perception in chess. *Cognitive Psychology, 4*(1), 55-81. [doi:10.1016/0010-0285(73)90004-2](https://doi.org/10.1016/0010-0285(73)90004-2)
6. Simon, H. A., & Gilmartin, K. (1973). A simulation of memory for chess positions. *Cognitive Psychology, 5*, 29-46. [record](https://psycnet.apa.org/record/1974-08458-001)
7. Kahneman, D., & Klein, G. (2009). Conditions for intuitive expertise: A failure to disagree. *American Psychologist, 64*(6), 515-526. [doi:10.1037/a0016755](https://doi.org/10.1037/a0016755)
8. Tetlock, P. E. (2005). *Expert Political Judgment: How Good Is It? How Can We Know?* Princeton University Press. (Talk summary: [Long Now Foundation](https://longnow.org/talks/02007-tetlock/))
9. Ericsson, K. A., Krampe, R. T., & Tesch-Römer, C. (1993). The role of deliberate practice in the acquisition of expert performance. *Psychological Review, 100*(3), 363-406. [doi:10.1037/0033-295X.100.3.363](https://doi.org/10.1037/0033-295X.100.3.363)
10. Macnamara, B. N., Hambrick, D. Z., & Oswald, F. L. (2014). Deliberate practice and performance in music, games, sports, education, and professions: A meta-analysis. *Psychological Science, 25*(8), 1608-1618. [doi:10.1177/0956797614535810](https://doi.org/10.1177/0956797614535810)
11. Ericsson, K. A. (2016). Summing up hours of any type of practice versus identifying optimal practice activities: Commentary on Macnamara, Moreau, & Hambrick (2016). *Perspectives on Psychological Science, 11*(3). [doi:10.1177/1745691616635600](https://doi.org/10.1177/1745691616635600)

*Updated: September 19, 2026*
